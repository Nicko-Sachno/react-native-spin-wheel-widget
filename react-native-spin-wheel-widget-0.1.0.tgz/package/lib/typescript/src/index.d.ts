import { type EmitterSubscription } from 'react-native';
import { type SpinWheelResult } from './NativeSpinWheelWidget.js';
export type { SpinWheelResult };
/** Payload emitted when a spin finishes on the home-screen widget (while the app is alive). */
export type SpinResultEvent = {
    /** Final resting angle in degrees (0–360). */
    angle: number;
    /** The app-widget id that spun. */
    widgetId: number;
    /** Index of the segment the wheel landed on. */
    segmentIndex: number;
    /** Hex color of the landed segment, e.g. '#7CB342'. */
    color: string;
    /** Human-readable name of the landed segment, e.g. 'Green'. */
    name: string;
};
/**
 * Point the widget at a remote JSON config, optionally overriding the asset host.
 * Pass an empty `assetsHost` to keep the host declared inside the fetched config.
 */
export declare function configure(configUrl: string, assetsHost?: string): void;
/** Push a full config JSON string to the widget (offline override). Pass '' to clear. */
export declare function setConfigJson(json: string): void;
/** Force the widget to reload its config + assets and re-render. */
export declare function refresh(): Promise<boolean>;
/** Read the widget's current persisted state (resting angle, last fetch time, config url). */
export declare function getLastResult(): SpinWheelResult;
/** Subscribe to spin-completion events. Returns a subscription; call `.remove()` to unsubscribe. */
export declare function addSpinResultListener(listener: (event: SpinResultEvent) => void): EmitterSubscription;
//# sourceMappingURL=index.d.ts.map